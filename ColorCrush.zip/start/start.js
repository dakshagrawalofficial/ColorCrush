window.addEventListener("keyup", ev => {
  if (ev.keyCode === 38) {
    //YOUR CODE HERE
    
    //example below
    document.body.innerHTML = "<h1 id='gameOn'>GAME ON!!!</h1>"
  }
});